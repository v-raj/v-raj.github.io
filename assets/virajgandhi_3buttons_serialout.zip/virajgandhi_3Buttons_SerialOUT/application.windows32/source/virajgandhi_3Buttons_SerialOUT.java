import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class virajgandhi_3Buttons_SerialOUT extends PApplet {

/*
By Viraj Gandhi
Fabacademy 2017

*/



ControlP5 cp5;


Textlabel myTextlabelA;
Textlabel myTextlabelB;
Textlabel myTextlabelC;
Textlabel myTextlabelV;



Serial myPort;  // Create object from Serial class

public void setup() {
   //***** Enebling serial to send data to arduino
 String portName = Serial.list()[0]; //change the 0 to a 1 or 2 etc. to match your port
  myPort = new Serial(this, portName, 9600);
  
  
  noStroke();
  cp5 = new ControlP5(this);
  

 

  cp5.addToggle("ServoA").setPosition(20,20).setSize(200,200)
    .setCaptionLabel("")
     .setColorBackground(color(177,255,50))
     .setColorActive(color(177,255,50))
     .setColorForeground(color(211,211,211));
  
  cp5.addToggle("ServoB").setPosition(230,20).setSize(200,200)
    .setCaptionLabel("")
     .setColorBackground(color(255, 153, 0))
     .setColorActive(color(255, 153, 0))
     .setColorForeground(color(211,211,211));
     
     cp5.addToggle("ServoC").setPosition(440,20).setSize(200,200)
    .setCaptionLabel("")
    .setColorBackground(color(255,105,180))
     .setColorActive(color(255,105,180))
     .setColorForeground(color(211,211,211));
     
     
     myTextlabelA = cp5.addTextlabel("label")
                    .setText("A")              
                    .setPosition(100,210)
                    .setColor(color(255,255,255))
                    .setFont(createFont("Agency FB",100))
                    ;
  myTextlabelB = cp5.addTextlabel("label2")
                    .setText("B")
                    .setPosition(300,210)
                    .setColor(color(255,255,255))
                    .setFont(createFont("Agency FB",100))
                    ;                                      

   myTextlabelC = cp5.addTextlabel("label3")
                    .setText("C")
                      .setPosition(500,210)
                    .setColor(color(255,255,255))
                    .setFont(createFont("Agency FB",100))
                    ;
  
  myTextlabelV = cp5.addTextlabel("label4")
                    .setText("Viraj Gandhi")
                      .setPosition(20,330)
                    .setColor(color(255,255,255))
                    .setFont(createFont("Agency FB",30))
                    ;
     myTextlabelV = cp5.addTextlabel("label5")
                    .setText("Interface Assginment Fabacademy 2017 "+"\n"+ "Servo Controller Via Serial Communication")
                      .setPosition(20,360)
                    .setColor(color(255,255,255))
                    .setFont(createFont("Agency FB",20))
                    ;

}

public void draw() {
  background(color(44, 62, 80));  //rgb()

}

public void controlEvent(ControlEvent theEvent) {
  println(theEvent.getController().getName());

}



public void ServoA(int theValue) {
  println("Button A Pressed: "+theValue);
  myPort.write("a"+theValue+"\n");
myTextlabelA.setText("A"+theValue);
}

public void ServoB(int theValue) {
  println("Button B Pressed: "+theValue);
  myPort.write("b"+theValue+"\n");
 myTextlabelB.setText("B"+theValue);
}

public void ServoC(int theValue) {
  println("Button C Pressed: "+theValue);
  myPort.write("c"+theValue+"\n");  
  myTextlabelC.setText("C"+theValue);
}
  public void settings() {  size(660,430); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "virajgandhi_3Buttons_SerialOUT" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
